library(shiny)
library(DT)
library(ggplot2)
library(dplyr)
#which teams collected the most points
# Define UI ----
ui <- fluidPage(
  sidebarLayout(
    sidebarPanel(
   
      dateInput("date", "Date:", value = '2021-10-07'),
      checkboxInput("includeDate", "Include Date", FALSE),
      selectInput("home", "Home Team:",
                  c("all")),
      selectInput("away", "Away Team:",
                  c("all")),
      actionButton("filter", "Filter")
      
    ),
    mainPanel(
      fluidRow(
        
        DTOutput('table')
        
      ),
      fluidRow(
        
        plotOutput('top')
        
      )
    )
  )
)

# Define server logic ----
server <- function(input, output,session) {
  
  data <- read.csv("Attachment_1637326132.csv", sep = ',')
  data$date = as.Date(data$date)
  updateSelectInput(session, "home",
                    label = "Home Team:",
                    choices =c("all",unique( data$home_team)),
                    selected = head(c("all",unique( data$home_team)), 1)
  )
  updateSelectInput(session, "away",
                    label = "Away Team:",
                    choices =c("all",unique( data$away_team)),
                    selected = head(c("all",unique(data$away_team)), 1)
  )
  
  output$table <- renderDataTable({
    datatable(
      data,
    options = list( pageLength = 5)
    
    )
    
  })
  
  
  observeEvent(input$filter,{
    
    tdata = data
    tdata$date = as.Date(tdata$date)
    if(input$includeDate ==  TRUE){
      
      tdata = filter(tdata,date == input$date)
    }
      
    
    if(input$home != "all"){
      tdata = filter(tdata,home_team == input$home)
    }
   
    if(input$away != "all"){
      tdata = filter(tdata,home_team == input$away)
    }
   
    output$table <- renderDataTable({
      datatable(
        tdata,
        options = list( pageLength = 5)
        
      )
       
      
    })
    
    
  })
  
  
  output$top <- renderPlot({
    sortedData = data[order(-data$home_score),]
    
    df <- data.frame(Score=c(sortedData$home_score[1:5]),
                     HomeTeam=c(sortedData$home_team[1:5]))
    
    ggplot(data=df, aes(x=HomeTeam, y=Score)) +
      geom_bar(stat="identity", fill="steelblue")+
      geom_text(aes(label=Score), vjust=1.6, color="white", size=3.5)+
      theme_minimal()+
      labs(title="Top 5 Home Teams")
  })
}

# Run the app ----
shinyApp(ui = ui, server = server)

# filter(data,date == Sys.Date())